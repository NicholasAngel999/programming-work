function revealMessage() {
    document.getElementById("hiddenMessage").style.display = "block";
}
